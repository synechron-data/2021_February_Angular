import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthenticatorService {
  private url: string;

  constructor(private httpClient: HttpClient) {
    this.url = "http://localhost:8000/account/getToken";
  }

  login(username: string, password: string) {
    return this.httpClient.post<any>(this.url, { username: username, password: password }).pipe(map(resObject => {
      if (resObject && resObject.token) {
        sessionStorage.setItem('tk', resObject.token);
      }
      return resObject;
    }), retry(3),
      catchError(this._handleError<any>('login')));
  }

  private _handleError<T>(operation = "operation", result?: T) {
    return (err: HttpErrorResponse): Observable<T> => {
      console.log(`${operation} failed: ${err.message}`);
      return throwError(err.error.message);
    }
  }

  getToken() {
    return sessionStorage.getItem('tk');
  }

  logout() {
    sessionStorage.removeItem('tk');
  }
}
