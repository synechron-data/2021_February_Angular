exports.index = function (req, res, next) {
    res.render('users/index', { title: 'Users View' });
}