var express = require('express');
var router = express.Router();

const home_ctrl = require('../controllers/home-controller');

router.get('/', home_ctrl.index);

module.exports = router;
