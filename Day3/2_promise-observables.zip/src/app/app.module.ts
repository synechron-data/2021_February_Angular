import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RootComponent } from './components/root/root.component';
import { AsyncPromiseComponent } from './components/async-promise/async-promise.component';
import { AsyncObservableComponent } from './components/async-observable/async-observable.component';

@NgModule({
  declarations: [RootComponent, AsyncPromiseComponent, AsyncObservableComponent],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  bootstrap: [RootComponent]
})
export class AppModule { }