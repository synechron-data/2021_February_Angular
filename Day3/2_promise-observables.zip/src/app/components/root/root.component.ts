import { Component, OnInit } from '@angular/core';
import { concat, EMPTY, Observable, Observer, of, Subject } from 'rxjs';
import { filter, map, reduce, startWith, delay } from 'rxjs/operators';

@Component({
  selector: 'root',
  templateUrl: './root.component.html'
})
export class RootComponent implements OnInit {
  subject?: Subject<number>;
  observable?: Observable<number>;

  constructor() {
    // this.getPromise().then(data => {
    //   console.log(`Promise Output - ${data}`);
    // }, err => {
    //   console.error(`Promise Error - ${err}`);
    // });

    // // this.getPromise();
    // // this.getObservable();

    // this.getObservable().subscribe(data => {
    //   console.log(`Observable Output - ${data}`);
    // }, err => {
    //   console.error(`Observable Error - ${err}`);
    // });

    // --------------------------------------------------------------
    // this.observable = this.getObservable();

    // this.observable.subscribe(data => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // });

    // this.observable.subscribe(data => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // });

    // --------------------------------------------------------------
    // this.subject = this.getSubject();

    // this.subject.subscribe(data => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // });

    // this.subject.subscribe(data => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // });

    // --------------------------------------------------------------
    // this.observable = this.getSubjectAsObservable();

    // this.observable.subscribe(data => {
    //   console.log(`Subscriber 1, Output - ${data}`);
    // });

    // this.observable.subscribe(data => {
    //   console.log(`Subscriber 2, Output - ${data}`);
    // });

    // -------------------------------------------------------------- Operators & Methods

    // let numOb = of(10, 20, 30, 40, 50, 60, 70);
    // numOb.subscribe(n => console.log(n));

    // let numOb = of(10, 20, 30, 40, 53, 60, 71, 81);
    // numOb.subscribe(n => console.log(n));

    // let evOb = numOb.pipe(
    //   filter(n => n % 2 == 0),
    //   map(n => n * 10),
    //   reduce((a, n) => a + n)
    // );

    // evOb.subscribe(n => console.log(n));

    // concat(
    //   of(10, 20, 30),
    //   of(40, 50, 60),
    // ).subscribe(n => console.log(n));

    // concat(
    //   this.delayedMessage("Get Ready"),
    //   this.delayedMessage(5),
    //   this.delayedMessage(4),
    //   this.delayedMessage(3),
    //   this.delayedMessage(2),
    //   this.delayedMessage(1),
    //   this.delayedMessage("Go Now")
    // ).subscribe(m => console.log(m));
  }

  delayedMessage(message: any, delayTime = 1000) {
    return EMPTY.pipe(startWith(message), delay(delayTime));
  }

  ngOnInit(): void {
  }

  getSubjectAsObservable(): Observable<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 2000);

    return s.asObservable();
  }

  getSubject(): Subject<number> {
    let s = new Subject<number>();

    setInterval(function () {
      s.next(Math.random());
    }, 2000);

    return s;
  }

  getObservable(): Observable<number> {
    return Observable.create((ob: Observer<number>) => {
      setInterval(function () {
        // console.log("Observable - Set Interval Executed....");
        ob.next(Math.random());
      }, 2000);
    })
  }

  getPromise(): Promise<number> {
    return new Promise((resolve, reject) => {
      setInterval(function () {
        // console.log("Promise - Set Interval Executed....");
        resolve(Math.random());
      }, 2000);
    })
  }
}
