import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Post } from "../models/post.interface";
import { catchError, delay, retry } from "rxjs/operators";
import { Observable, throwError } from "rxjs";

// 'root' : The application-level injector in most apps.
// 'platform' : A special singleton platform injector shared by all applications on the page.
// 'any' : Provides a unique instance in each lazy loaded module, while all eagerly loaded modules share one instance.

// @Injectable()
@Injectable({
    providedIn: 'root'
})
export class PostService {
    private url: string;

    constructor(private httpClient: HttpClient) {
        this.url = "https://jsonplaceholder.typicode.com/posts";
    }

    // getPosts() {
    //     return this.httpClient.get<Array<Post>>(this.url);
    // }

    getPosts() {
        return this.httpClient.get<Array<Post>>(this.url).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('getPosts', []))
        );
    }

    insertPost(data: Post) {
        return this.httpClient.post<Post>(this.url, data).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('insertPost', data))
        );
    }

    deletePost(id: number) {
        var deleteUrl = `${this.url}/${id}`;

        return this.httpClient.delete(deleteUrl).pipe(
            delay(3000),
            retry(3),
            catchError(this._handleError('deletePost'))
        );
    }

    private _handleError<T>(operation = "operation", result?: T) {
        return (err: HttpErrorResponse): Observable<T> => {
            // Error Logging
            console.error(`${operation} failed: ${err.message}`);
            return throwError('Connection Error, plase try again later....');
        }
    }
}