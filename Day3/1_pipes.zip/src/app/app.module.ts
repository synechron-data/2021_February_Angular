import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RootComponent } from './components/root/root.component';
import { ListComponent } from './components/list/list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CaptionPipe } from './pipes/caption.pipe';
import { FilterPipe } from './pipes/filter.pipe';

@NgModule({
  declarations: [RootComponent, ListComponent, CaptionPipe, FilterPipe],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  bootstrap: [RootComponent]
})
export class AppModule { }