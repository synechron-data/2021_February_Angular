import { AfterViewInit, Component, NgZone, OnInit } from '@angular/core';

@Component({
  selector: 'root',
  templateUrl: './root.component.html'
})
export class RootComponent implements OnInit, AfterViewInit {
  message: string;
  flag: boolean;
  h: number;
  w: number;
  city: string;

  constructor(private ngZone: NgZone) {
    this.message = "Hello World!";
    this.flag = false;
    this.h = 200;
    this.w = 200;
    this.city = "";
  }

  ngOnInit(): void {
  }

  changeMessage() {
    this.message = new Date().toLocaleTimeString();
  }

  ngAfterViewInit(): void {
    // document.getElementById("btnJS")?.addEventListener("click", () => {
    //   this.message = new Date().toLocaleTimeString();
    // });

    this.ngZone.runOutsideAngular(() => {
      document.getElementById("btnJS")?.addEventListener("click", () => {
        this.message = new Date().toLocaleTimeString();
        console.log(this.message);
      });
    })
  }

  doUpdate(c: string) {
    this.message = `You are from: ${c}`;
  }
}
