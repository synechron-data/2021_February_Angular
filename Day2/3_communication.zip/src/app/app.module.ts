import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RootComponent } from './components/root/root.component';
import { ListComponent } from './components/list/list.component';
import { CounterComponent } from './components/counter/counter.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [RootComponent, ListComponent, CounterComponent],
  imports: [BrowserModule, FormsModule],
  bootstrap: [RootComponent]
})
export class AppModule { }