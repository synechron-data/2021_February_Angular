import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomValidator } from 'src/app/utilities/CustomValidator';

@Component({
  selector: 'validation-form',
  templateUrl: './validation-form.component.html',
  styles: [
  ]
})
export class ValidationFormComponent implements OnInit {
  regForm?: FormGroup;

  minAge = 18;
  maxAge = 60;

  constructor(private frmBuilder: FormBuilder) { }

  get frm() { return this.regForm?.controls; }
  get address() { return (<FormGroup>this.regForm?.controls.address).controls; }

  ngOnInit(): void {
    this.regForm = this.frmBuilder.group({
      firstname: ["", Validators.required],
      lastname: ["", Validators.compose([
        Validators.required,
        Validators.maxLength(6),
        Validators.minLength(2)
      ])],
      age: ["", [
        Validators.required,
        // CustomValidator.ageRangeValidator
        CustomValidator.ageRangeValidator(this.minAge, this.maxAge)
      ]],
      address: this.frmBuilder.group({
        city: ["", Validators.required],
        zip: ["", Validators.required]
      })
    });
  }

  logForm() {
    if (this.regForm?.valid)
      console.log(this.regForm?.value);
    else {
      this.regForm?.markAllAsTouched();
      console.error("Invalid Form Data");
    }
  }
}
