import { Component, NgZone, OnInit } from '@angular/core';

@Component({
  selector: 'root',
  templateUrl: './root.component.html'
})
export class RootComponent implements OnInit {
  flag: boolean;
  myStyles: any;
  name: string;

  constructor(private ngZone: NgZone) {
    this.flag = false;
    this.myStyles = {
      'background-color': 'green',
      'font-size': '20px',
      'color': 'white'
    };
    this.name = "";
    // this.name = "Synechron";
  }

  ngOnInit(): void {
  }
}
