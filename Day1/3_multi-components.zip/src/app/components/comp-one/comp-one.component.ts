import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'comp-one',
  templateUrl: './comp-one.component.html'
})
export class CompOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
