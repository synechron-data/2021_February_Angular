import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'comp-two',
  templateUrl: './comp-two.component.html'
})
export class CompTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
