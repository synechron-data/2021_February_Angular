// import { Component, ViewEncapsulation } from '@angular/core';

// @Component({
//   selector: 'comp-one',
//   templateUrl: './comp-one.component.html',
//   encapsulation: ViewEncapsulation.ShadowDom
// })
// export class CompOneComponent {}

// Component Style
// import { Component } from '@angular/core';

// @Component({
//   selector: 'comp-one',
//   templateUrl: './comp-one.component.html',
//   styles:[`
//     .card {
//         border-style: solid; 
//         border-width:2px; 
//         border-color:blue;
//     }
//   `]
// })
// export class CompOneComponent {}

// External CSS
import { Component } from '@angular/core';

@Component({
  selector: 'comp-one',
  templateUrl: './comp-one.component.html',
  styleUrls: ['./comp-one.component.css']
})
export class CompOneComponent {}
