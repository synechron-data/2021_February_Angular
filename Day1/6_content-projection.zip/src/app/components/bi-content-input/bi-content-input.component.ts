import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'bi-content-input',
  templateUrl: './bi-content-input.component.html',
  styleUrls: ['./bi-content-input.component.css']
})
export class BiContentInputComponent implements OnInit {
  @Input() icon?: string;

  get classes() {
    const cssClasses: any = {
      bi: true
    };

    cssClasses['bi-' + this.icon] = true;
    return cssClasses;
  }

  constructor() { }

  ngOnInit(): void {
  }
}
