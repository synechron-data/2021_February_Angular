import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'bi-input',
  templateUrl: './bi-input.component.html',
  styleUrls: ['./bi-input.component.css']
})
export class BiInputComponent implements OnInit {
  @Input() icon?: string;

  get classes() {
    const cssClasses: any = {
      bi: true
    };

    cssClasses['bi-' + this.icon] = true;
    return cssClasses;
  }

  constructor() { }

  ngOnInit(): void {
  }
}
