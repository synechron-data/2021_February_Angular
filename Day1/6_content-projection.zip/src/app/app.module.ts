import { APP_BOOTSTRAP_LISTENER, ComponentRef, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RootComponent } from './components/root/root.component';
import { HelloComponent } from './components/hello/hello.component';
import { BiInputComponent } from './components/bi-input/bi-input.component';
import { BiContentInputComponent } from './components/bi-content-input/bi-content-input.component';

@NgModule({
  declarations: [RootComponent, HelloComponent, BiInputComponent, BiContentInputComponent],
  imports: [BrowserModule],
  providers: [
    {
      provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
        return function (component: ComponentRef<any>) {
          console.log(component);
        }
      }
    }
  ],
  bootstrap: [RootComponent]
})
export class AppModule { }