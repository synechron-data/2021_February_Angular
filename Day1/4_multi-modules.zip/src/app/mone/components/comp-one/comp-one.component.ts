import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'comp-one',
  templateUrl: './comp-one.component.html',
  styles: [
  ]
})
export class CompOneComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
