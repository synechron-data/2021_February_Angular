import { Component, OnInit } from '@angular/core';

@Component({
  selector: 's-comp',
  templateUrl: './s-comp.component.html',
  styles: [
  ]
})
export class SCompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
