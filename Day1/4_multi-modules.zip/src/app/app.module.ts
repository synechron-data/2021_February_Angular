import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RootComponent } from './components/root/root.component';
import { MoneModule } from './mone/mone.module';
import { MtwoModule } from './mtwo/mtwo.module';
import { SharedModule } from './shared/shared.module';

// Add declarable classes (components, directives, and pipes) to a declarations list.

@NgModule({
  declarations: [RootComponent],
  imports: [BrowserModule, MoneModule, MtwoModule, SharedModule],
  bootstrap: [RootComponent]
})
export class AppModule { }