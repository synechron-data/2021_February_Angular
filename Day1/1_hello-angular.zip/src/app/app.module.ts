// import { NgModule } from '@angular/core';
// import { BrowserModule } from '@angular/platform-browser';
// import { HelloComponent } from './components/hello/hello.component';

// @NgModule({
//   declarations: [HelloComponent],
//   imports: [BrowserModule],
//   bootstrap: [HelloComponent]
// })
// export class AppModule { }

// -------------------------------------- Manual

import { ApplicationRef, DoBootstrap, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HelloComponent } from './components/hello/hello.component';

@NgModule({
  declarations: [HelloComponent],
  imports: [BrowserModule],
  entryComponents: [HelloComponent]
})
export class AppModule implements DoBootstrap {
  ngDoBootstrap(appRef: ApplicationRef): void {
    const container = document.querySelector("#container");

    const helloElement = document.createElement('app-hello');
    container?.appendChild(helloElement);
    appRef.bootstrap(HelloComponent);
  }
}
